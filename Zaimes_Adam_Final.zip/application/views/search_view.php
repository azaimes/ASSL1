<br>
<div class="container">
  <div class="row">
    <form method="GET" action="http://api.wunderground.com/api/872a1eab6cc42425/geolookup/conditions/q/state=/.json">
    	<label>City: <input type="text" name="city" value="City"></label>
    	<label>State: <input type="text" name="state" value="State"></label>



    </form>
  </div>
</div>